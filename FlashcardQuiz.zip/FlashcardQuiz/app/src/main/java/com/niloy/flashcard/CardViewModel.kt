package com.niloy.flashcard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CardViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).cardDao()

    val cards: StateFlow<List<Flashcard>> = dao.getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(question: String, answer: String) {
        viewModelScope.launch {
            dao.insert(Flashcard(question = question.trim(), answer = answer.trim()))
        }
    }

    fun update(card: Flashcard) {
        viewModelScope.launch { dao.update(card) }
    }

    fun delete(card: Flashcard) {
        viewModelScope.launch { dao.delete(card) }
    }
}
