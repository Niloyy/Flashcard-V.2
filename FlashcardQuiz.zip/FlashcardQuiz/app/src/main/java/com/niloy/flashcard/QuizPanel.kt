package com.niloy.flashcard

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

enum class QuizMode { OVERLAY, PRACTICE }

private val GreenOk = Color(0xFF4CAF50)
private val RedBad = Color(0xFFEF5350)

/**
 * Ekta card er quiz UI.
 * OVERLAY: thik hole dismiss, vul hole lockSeconds por por lock.
 * PRACTICE: app er bhitore practice, lock nai.
 */
@Composable
fun QuizPanel(
    card: Flashcard,
    mode: QuizMode,
    lockSeconds: Int,
    onFinished: () -> Unit,
    onEmergency: () -> Unit = {}
) {
    val input = remember { MathInputState() }
    var result by remember { mutableStateOf<Boolean?>(null) }
    val base = if (mode == QuizMode.OVERLAY) Modifier.systemBarsPadding() else Modifier

    Box(base.fillMaxSize().padding(12.dp)) {
        val r = result
        when {
            r == null -> AskLayout(card, mode, input) {
                result = normalizeAnswer(input.text) == normalizeAnswer(card.answer)
            }
            r -> CorrectLayout(mode, onFinished)
            mode == QuizMode.OVERLAY -> LockLayout(card, lockSeconds, onFinished, onEmergency)
            else -> PracticeWrongLayout(card, onFinished)
        }
    }
}

@Composable
private fun AskLayout(card: Flashcard, mode: QuizMode, input: MathInputState, onCheck: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        if (mode == QuizMode.OVERLAY) {
            Text(
                "Quiz time! Answer dao, na hole phone lock hobe",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 8.dp)
        ) {
            Text(card.question, style = MaterialTheme.typography.headlineSmall)
        }
        MathField(input, "Tomar answer", active = true)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onCheck,
            enabled = input.text.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Check") }
        Spacer(Modifier.height(8.dp))
        MathKeyboard(input)
    }
}

@Composable
private fun CorrectLayout(mode: QuizMode, onFinished: () -> Unit) {
    val scale = remember { Animatable(0.3f) }
    LaunchedEffect(Unit) {
        scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
        if (mode == QuizMode.OVERLAY) {
            delay(900)
            onFinished()
        }
    }
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "✓",
            fontSize = 110.sp,
            color = GreenOk,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            }
        )
        Text("Correct!", style = MaterialTheme.typography.headlineMedium, color = GreenOk)
        if (mode == QuizMode.PRACTICE) {
            Spacer(Modifier.height(24.dp))
            Button(onClick = onFinished) { Text("Next") }
        }
    }
}

@Composable
private fun PracticeWrongLayout(card: Flashcard, onFinished: () -> Unit) {
    val shake = rememberShake()
    Column(
        Modifier
            .fillMaxSize()
            .offset(x = shake.value.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("✗", fontSize = 90.sp, color = RedBad, fontWeight = FontWeight.Bold)
        Text("Vul!", style = MaterialTheme.typography.headlineMedium, color = RedBad)
        Spacer(Modifier.height(16.dp))
        Text("Sothik answer:", style = MaterialTheme.typography.labelLarge)
        Text(card.answer, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onFinished) { Text("Next") }
    }
}

@Composable
private fun rememberShake(): Animatable<Float, androidx.compose.animation.core.AnimationVector1D> {
    val shake = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        shake.animateTo(
            0f,
            keyframes {
                durationMillis = 500
                -18f at 60
                18f at 160
                -14f at 260
                14f at 360
                -7f at 440
                0f at 500
            }
        )
    }
    return shake
}

@Composable
private fun LockLayout(
    card: Flashcard,
    lockSeconds: Int,
    onFinished: () -> Unit,
    onEmergency: () -> Unit
) {
    val totalMs = lockSeconds * 1000L
    val endAt = remember { SystemClock.elapsedRealtime() + totalMs }
    var remainingMs by remember { mutableLongStateOf(totalMs) }
    val shake = rememberShake()

    LaunchedEffect(Unit) {
        while (true) {
            val left = endAt - SystemClock.elapsedRealtime()
            if (left <= 0L) {
                remainingMs = 0L
                break
            }
            remainingMs = left
            delay(100)
        }
        onFinished()
    }

    val pulseTransition = rememberInfiniteTransition(label = "pulse")
    val pulse by pulseTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseScale"
    )

    val totalSec = ((remainingMs + 999) / 1000).toInt()
    val timeText = "%d:%02d".format(totalSec / 60, totalSec % 60)
    val fraction = if (totalMs > 0) remainingMs.toFloat() / totalMs.toFloat() else 0f
    val trackColor = MaterialTheme.colorScheme.surfaceVariant

    Column(
        Modifier
            .fillMaxSize()
            .offset(x = shake.value.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Vul! Phone locked", style = MaterialTheme.typography.headlineMedium, color = RedBad)
        Spacer(Modifier.height(20.dp))

        Box(
            Modifier
                .size(220.dp)
                .graphicsLayer {
                    scaleX = pulse
                    scaleY = pulse
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 16.dp.toPx()
                val arcSize = Size(size.width - sw, size.height - sw)
                val topLeft = Offset(sw / 2, sw / 2)
                drawArc(
                    color = trackColor,
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = sw, cap = StrokeCap.Round)
                )
                drawArc(
                    color = RedBad,
                    startAngle = -90f,
                    sweepAngle = 360f * fraction,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = sw, cap = StrokeCap.Round)
                )
            }
            Text(timeText, fontSize = 44.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(24.dp))
        Text("Sothik answer, ekhon mone rakho:", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(6.dp))
        Text(
            card.answer,
            style = MaterialTheme.typography.headlineSmall,
            textAlign = TextAlign.Center,
            color = GreenOk
        )

        Spacer(Modifier.height(32.dp))
        Text(
            "Emergency? Ekhane press kore dhore rakho",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.outline,
            modifier = Modifier
                .padding(12.dp)
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { onEmergency() })
                }
        )
    }
}
