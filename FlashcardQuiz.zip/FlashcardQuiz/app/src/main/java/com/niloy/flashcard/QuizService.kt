package com.niloy.flashcard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

/** ComposeView ke Service er overlay window e chalate lifecycle owner lage. */
private class OverlayOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val registry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = registry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateController.savedStateRegistry

    fun create() {
        savedStateController.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
    }

    fun resume() {
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}

class QuizService : Service() {

    companion object {
        const val ACTION_START = "com.niloy.flashcard.START"
        const val ACTION_STOP = "com.niloy.flashcard.STOP"
        const val ACTION_TEST = "com.niloy.flashcard.TEST"
        private const val CHANNEL_ID = "quiz_mode"
        private const val NOTIF_ID = 1

        fun send(context: Context, action: String) {
            val intent = Intent(context, QuizService::class.java).setAction(action)
            ContextCompat.startForegroundService(context, intent)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager

    private var overlayRoot: FrameLayout? = null
    private var overlayOwner: OverlayOwner? = null

    private val showRunnable = Runnable { tryShow() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startAsForeground()
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        val prefs = Prefs(this)
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.enabled = false
                handler.removeCallbacksAndMessages(null)
                removeOverlay()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TEST -> {
                handler.postDelayed({ showOverlay() }, 3000)
                if (!prefs.enabled) return START_NOT_STICKY
            }
            else -> {
                if (!prefs.enabled) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                if (overlayRoot == null) scheduleNext()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeOverlay()
        scope.cancel()
        super.onDestroy()
    }

    // ---------------- scheduling ----------------

    private fun scheduleNext() {
        handler.removeCallbacks(showRunnable)
        val prefs = Prefs(this)
        val minMs = prefs.minMinutes * 60_000L
        val maxMs = maxOf(prefs.maxMinutes, prefs.minMinutes) * 60_000L
        val delayMs = if (maxMs > minMs) Random.nextLong(minMs, maxMs + 1) else minMs
        handler.postDelayed(showRunnable, delayMs)
    }

    private fun tryShow() {
        if (overlayRoot != null) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) {
            // screen off, 30 sec por abar check
            handler.postDelayed(showRunnable, 30_000)
            return
        }
        showOverlay()
    }

    private fun afterDone() {
        if (Prefs(this).enabled) scheduleNext() else stopSelf()
    }

    // ---------------- overlay ----------------

    private fun showOverlay() {
        if (overlayRoot != null) return
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission nai, quiz mode bondho", Toast.LENGTH_LONG).show()
            Prefs(this).enabled = false
            stopSelf()
            return
        }
        scope.launch {
            val cards = withContext(Dispatchers.IO) {
                AppDatabase.get(this@QuizService).cardDao().getAllOnce()
            }
            if (cards.isEmpty()) {
                afterDone()
                return@launch
            }
            if (overlayRoot != null) return@launch
            val lockSeconds = Prefs(this@QuizService).lockMinutes * 60
            addOverlay(cards.random(), lockSeconds)
        }
    }

    private fun addOverlay(card: Flashcard, lockSeconds: Int) {
        val service = this
        val mainHandler = handler
        val owner = OverlayOwner().also { it.create() }

        val root = object : FrameLayout(service) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) return true
                return super.dispatchKeyEvent(event)
            }
        }
        root.isFocusable = true
        root.isFocusableInTouchMode = true
        root.setViewTreeLifecycleOwner(owner)
        root.setViewTreeSavedStateRegistryOwner(owner)
        root.setViewTreeViewModelStoreOwner(owner)

        val compose = ComposeView(service).apply {
            setContent {
                MaterialTheme(colorScheme = darkColorScheme()) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        QuizPanel(
                            card = card,
                            mode = QuizMode.OVERLAY,
                            lockSeconds = lockSeconds,
                            onFinished = {
                                mainHandler.post {
                                    removeOverlay()
                                    afterDone()
                                }
                            },
                            onEmergency = {
                                mainHandler.post {
                                    removeOverlay()
                                    openDialer()
                                    afterDone()
                                }
                            }
                        )
                    }
                }
            }
        }
        root.addView(
            compose,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        )

        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            Toast.makeText(service, "Overlay dekhano gelo na: ${e.message}", Toast.LENGTH_LONG).show()
            owner.destroy()
            afterDone()
            return
        }
        owner.resume()
        root.requestFocus()
        overlayRoot = root
        overlayOwner = owner
    }

    private fun removeOverlay() {
        val root = overlayRoot ?: return
        (root.getChildAt(0) as? ComposeView)?.disposeComposition()
        try {
            wm.removeView(root)
        } catch (_: Exception) {
        }
        overlayOwner?.destroy()
        overlayRoot = null
        overlayOwner = null
    }

    private fun openDialer() {
        try {
            startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    // ---------------- notification ----------------

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Quiz mode", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, QuizService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Flashcard quiz mode ON")
            .setContentText("Random somoy e quiz ashbe")
            .setContentIntent(openPi)
            .addAction(0, "Stop", stopPi)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }
}
